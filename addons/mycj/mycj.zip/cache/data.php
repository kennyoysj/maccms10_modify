<?php
$faves=array (
  0 => 
  array (
    'flag' => '8090zy',
    'name' => '8090资源站',
    'rema' => '腾讯视频直链',
    'apis' => '5tVMEg3kERRB4t+axlAQ6/1QkdXPTiq22Wy0pQfWaAvsZdeHUpqrosMNiAPCCoP1gLzU13znocaMxi9v7LWltQ==',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
    'coll' => 'Vu/fQy5D7fLiSCQcUrNJ4RN67ILGf2iovkap2FWwS6U=',
    'zylink' => '5tVMEg3kERRB4t+axlAQ68EGHg76Tas4IiGJ4W8TJ5Y=',
  ),
  1 => 
  array (
    'flag' => '8090zy',
    'name' => '8090资源站',
    'rema' => '爱奇艺视频直链',
    'apis' => '5tVMEg3kERRB4t+axlAQ6/1QkdXPTiq22Wy0pQfWaAv3ZxDRB4pxqkIy/RK7MDxbvCXEPnAaz8CDDVkF5PF1eg==',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
    'coll' => 'jNLJXHxX6fyZT63wDpKiiIMLgUnN83W0xDo8jPKhpvY=',
    'zylink' => '5tVMEg3kERRB4t+axlAQ68EGHg76Tas4IiGJ4W8TJ5Y=',
  ),
  2 => 
  array (
    'flag' => '8090zy',
    'name' => '8090资源站',
    'rema' => '优酷视频直链',
    'apis' => '5tVMEg3kERRB4t+axlAQ6/1QkdXPTiq22Wy0pQfWaAvV9KQAe4Wr3h8O9VYIdknvcBH8CH/0bX0WUZnrbdR9+Q==',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
    'coll' => 'rC6E4jnmHwlqDD4VB3dwPrcRVp6JCZVr+AZPfYgCyec=',
    'zylink' => '5tVMEg3kERRB4t+axlAQ68EGHg76Tas4IiGJ4W8TJ5Y=',
  ),
  3 => 
  array (
    'flag' => '8090zy',
    'name' => '8090资源站',
    'rema' => '芒果视频直链',
    'apis' => '5tVMEg3kERRB4t+axlAQ6/1QkdXPTiq22Wy0pQfWaAtCnsGzv2A5cfpk1QMskPycgfxkAhUu9Ye6DQrDp/r6rA==',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
    'coll' => 't6sIKoDVBbR9n1HYgdOyRH9XVD9Hw+oqXiZed6fvRMg=',
    'zylink' => '5tVMEg3kERRB4t+axlAQ68EGHg76Tas4IiGJ4W8TJ5Y=',
  ),
  4 => 
  array (
    'flag' => '8090zy',
    'name' => '8090资源站',
    'rema' => '搜狐视频直链',
    'apis' => '5tVMEg3kERRB4t+axlAQ6/1QkdXPTiq22Wy0pQfWaAuSw4mjv3NF6/ubdLKSvOYjK+YPIkYSRIwKLZpp6hl6KA==',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
    'coll' => 'fJVnuMZ+AKLf2yHWC3LYmYcjL1NyTVqTGYynXjzEMDk=',
    'zylink' => '5tVMEg3kERRB4t+axlAQ68EGHg76Tas4IiGJ4W8TJ5Y=',
  ),
  5 => 
  array (
    'flag' => '8090zy',
    'name' => '8090资源站',
    'rema' => '乐视视频直链',
    'apis' => '5tVMEg3kERRB4t+axlAQ6/1QkdXPTiq22Wy0pQfWaAsCRb29+YzMKWieniVB9sKY+5eGzauToRld7nbhnoccbQ==',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
    'coll' => '5IrSk9T2oDZcroqPSPdLbq9RGRwReX9Wx9Z+XpWY3/A=',
    'zylink' => '5tVMEg3kERRB4t+axlAQ68EGHg76Tas4IiGJ4W8TJ5Y=',
  ),
  6 => 
  array (
    'flag' => '8090zy',
    'name' => '8090资源站',
    'rema' => 'PPTV视频直链',
    'apis' => '5tVMEg3kERRB4t+axlAQ6/1QkdXPTiq22Wy0pQfWaAu5O8FUvJT7Xjl8geA1Lbqyl3ytg4Y+FKioOiSRBW68lQ==',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
    'coll' => 'USvxAamsjgoq0NHucMnx6W9pO+TleTbOzvurhL8Vg3Q=',
    'zylink' => '5tVMEg3kERRB4t+axlAQ68EGHg76Tas4IiGJ4W8TJ5Y=',
  ),
  7 => 
  array (
    'flag' => '8090zy',
    'name' => '8090资源站',
    'rema' => '咪咕视频网直链',
    'apis' => '5tVMEg3kERRB4t+axlAQ6/1QkdXPTiq22Wy0pQfWaAujQ/q0VGOMM3Tz5Ks0FQ+1hZgimiw00le5lWDbUSD3HQ==',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
    'coll' => 'FKXSiynhKmfpCkzk14hzAXL4jpOR2jhgN42ycJfcwmc=',
    'zylink' => '5tVMEg3kERRB4t+axlAQ68EGHg76Tas4IiGJ4W8TJ5Y=',
  ),
  8 => 
  array (
    'flag' => '8090zy',
    'name' => '8090资源站',
    'rema' => '华硕视频网直链',
    'apis' => '5tVMEg3kERRB4t+axlAQ6/1QkdXPTiq22Wy0pQfWaAvfnI6eRzWBiJWci1SGGRlbQmyhLPGqwzP32Ut/SPodVQ==',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
    'coll' => 'O/0yJCotEIgXg6116U37hBlcQGa+26o6XXJFsvDUpJ0=',
    'zylink' => '5tVMEg3kERRB4t+axlAQ68EGHg76Tas4IiGJ4W8TJ5Y=',
  ),
  9 => 
  array (
    'flag' => '8090zy',
    'name' => '8090资源站',
    'rema' => '风行视频网直链',
    'apis' => '5tVMEg3kERRB4t+axlAQ6/1QkdXPTiq22Wy0pQfWaAsmTrNiQI1WJhEZoLbcntRHhSH/lIx0x9bNTD8JK3YXaA==',
    'tips' => '<span class="layui-badge layui-bg-green">我的收藏</span>',
    'coll' => 'T1l4UBjM9z9HLA65zP296Fis9NORTJ5d0Q3JOwjbeg4=',
    'zylink' => '5tVMEg3kERRB4t+axlAQ68EGHg76Tas4IiGJ4W8TJ5Y=',
  ),
);
