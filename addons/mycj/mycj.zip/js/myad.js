var ads = {
	'advs': {
		'head': '本插件由『萌芽模板网』提供 >>> ',
		'tips': '<span style="font-size:14px;">官方网站：<a href="//www.vrecf.com">www.vrecf.com</a> >>> 广告投放 >> 咨询QQ：<a href="http://wpa.qq.com/msgrd?v=3&uin=209910539&site=qq&menu=yes" class="layui-badge layui-bg-red">209910539</a> >>></span>',
		'rows': [{
			'urls': 'http://www.vrecf.com/a/167.html',
			'tips': '<b style="color:#01AAED">天翼云网盘解析程序 一键发布到苹果cms</b>',
			'tip1': '<b style="color:red">【带后台】Dplayer播放器 可设置前置暂停广告</b>',
			'url1': 'http://www.vrecf.com/a/223.html',
			'tip2': '<b style="color:blue">【带后台】Ckplayer播放器 可设置前置暂停广告</b>',
			'url2': 'http://www.vrecf.com/a/225.html',
			'tip3': '<b style="color:#FF5722;font-size:18px">苹果cmsV10 V8程序下载</b>',
			'url3': 'http://www.vrecf.com/maccms/',
			'tip4': '<b style="color:#5FB878">建站首选 最低8元/月 免备案虚拟主机</b>',
			'url4': 'https://www.vpsor.cn/aff?affid=15427'
		}]
	}
}
