<?php
/**
Admin采集插件中心 版权所有 ：www.admincj.com
**/
namespace addons\admin;use think\Addons;class admin extends Addons{public function install(){return true;}public function uninstall(){return true;}}