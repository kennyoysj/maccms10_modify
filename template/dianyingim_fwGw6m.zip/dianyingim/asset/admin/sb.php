<?php
return array (
  'dscms' => 
  array (
    'jc' => 
    array (
      'logo1' => 'template/dianyingim/img/index-logo.png',
      'logo2' => 'template/dianyingim/img/logo2.png',
      'icon' => 'template/dianyingim/img/logo.png',
      'pic' => 'template/dianyingim/img/loading.png',
      'gg' => '感谢使用电影先生开源项目',
      'txt' => '<p>电影先生</p>
<p>模板交流qq群：872882160</p>
<p>如遇到任何问题可加作者群反馈</p>
<p>作者qq群：<a href="https://jq.qq.com/?_wv=1027&k=ctsUKe9L" target="_blank"><strong>点击这里快速加入群聊</strong></a>',
      'zhizhang' => '感谢您使用本源码，如果喜欢请多多传播 😊',
      'sm' => '本站所有内容均来自互联网分享站点所提供的公开引用资源，未提供影视资源上传、存储服务。',
    ),
    'nav' => 
    array (
      'actor' => '1',
      'topic' => '1',
      'vip' => '1',
      'ivi' => '1',
      'zdyname1' => 'aaa1',
      'zdyurl1' => '111',
    ),
    'indexactor' => '1',
  ),
);